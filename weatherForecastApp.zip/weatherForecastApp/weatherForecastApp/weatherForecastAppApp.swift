//
//  weatherForecastAppApp.swift
//  weatherForecastApp
//
//  Created by Mohd Abdul Subhan on 10/5/24.
//

import SwiftUI

@main
struct weatherForecastAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
