//
//  weatherView.swift
//  weatherForecastApp
//
//  Created by Mohd Abdul Subhan on 10/6/24.
//

import Foundation
import SwiftUI

struct WeatherView: View {
    var weather: Weather

    var body: some View {
        VStack(spacing: 2) {
            Text(weather.day)
                .fontWeight(.bold).font(.system(size: 30))

            Text("\(Int(weather.temperature))°")
                .font(.system(size: 30))
                .fontWeight(.bold)

            Image(systemName: weather.icon) 
                .resizable()
                .scaledToFit()
                .frame(width: 20, height: 20)
                .foregroundColor(.yellow)

            Text(weather.condition)
                .font(.title2)
                .foregroundColor(.black)
        }
        .padding()
        .background(Color.white.opacity(0.5))
        .cornerRadius(15)
        .shadow(radius: 10)
    }
}
