//
//  ContentView.swift
//  weatherForecastApp
//
//  Created by Mohd Abdul Subhan on 10/5/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            
            Image("backGround").resizable().scaledToFill().edgesIgnoringSafeArea(.all).opacity(0.6)
            VStack{
                Text("SkyWatch").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).bold()
                Text("Forecasting Your Day, One Cloud at a Time! \n\n")
                let weekWeatherRow1: [Weather] = [
                    Weather(day: "Mon", temperature: 75.0, condition: "Sunny", icon: "sun.max.fill"),
                    Weather(day: "Tue", temperature: 60.0, condition: "Rainy", icon: "cloud.rain.fill"),
                    Weather(day: "Wed", temperature: 45.0, condition: "Snowy", icon: "snow")
                ]
                let weekWeatherRow2: [Weather] = [
                    Weather(day: "Thu", temperature: 55.0, condition: "Windy", icon: "wind"),
                    Weather(day: "Fri", temperature: 70.0, condition: "Cloudy", icon: "cloud"),
                    Weather(day: "Sat", temperature: 80.0, condition: "Sunny", icon: "sun.max.fill")
                ]
                let weekWeatherRow3: [Weather] = [
                    Weather(day: "Sun", temperature: 65.0, condition: "Thunderstorms", icon: "cloud.bolt.fill")
                ]
                
                HStack{
                    ForEach(weekWeatherRow1, id: \.day) {
                        weather in WeatherView(weather: weather)
                    }
                }
                HStack{
                    ForEach(weekWeatherRow2, id: \.day) {
                        weather in WeatherView(weather: weather)
                    }
                }
                HStack{
                    ForEach(weekWeatherRow3, id: \.day){
                        weather in WeatherView(weather: weather)
                    }
                }
               
                }
            }
        }
    }
    
    #Preview {
        ContentView()
    }
    
