//
//  weather.swift
//  weatherForecastApp
//
//  Created by Mohd Abdul Subhan on 10/6/24.
//

import Foundation

struct Weather {
    let day:String
    let temperature: Double
    let condition: String
    let icon: String // You can use system icons or images
}
