//
//  AuthappTests.swift
//  AuthappTests
//
//  Created by Mohd Abdul Subhan on 10/27/24.
//

import Testing
@testable import Authapp

struct AuthappTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
