//
//  SignupScreen.swift
//  Authapp
//
//  Created by Mohd Abdul Subhan on 10/27/24.
//

import SwiftUI

struct SignupScreen: View {
    @State private var email = ""
    @State private var password = ""
    @Binding var isUserAuthenticated: Bool
    
    var body: some View {
        VStack {
            Spacer()
            Text("Sign Up")
                .font(.largeTitle).foregroundStyle(Color.white)
                .padding()
            
            TextField("Email", text: $email)
                .autocapitalization(.none)
                .padding()
                .background(Color.white)
                .cornerRadius(5)
            
            SecureField("Password", text: $password)
                .padding()
                .background(Color.white)
                .cornerRadius(5)
            
            Button(action: signUpUser) {
                Text("Sign Up")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green)
                    .cornerRadius(10)
            }
            .padding(.top, 20)
            Spacer()
        }
        .padding()
        .background(Color.black)
    }
    
    // Simulated signup function
    func signUpUser() {
        // Set isUserAuthenticated to true to simulate successful signup
        isUserAuthenticated = true
    }
}
#Preview {
    SignupScreen(isUserAuthenticated: .constant(false))
}

