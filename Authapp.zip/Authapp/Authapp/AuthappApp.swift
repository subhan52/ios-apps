//
//  AuthappApp.swift
//  Authapp
//
//  Created by Mohd Abdul Subhan on 10/27/24.
//

import SwiftUI

@main
struct AuthappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
