//
//  LoginScreen.swift
//  Authapp
//
//  Created by Mohd Abdul Subhan on 10/27/24.
//

import SwiftUI

struct LoginScreen: View {
    @State private var email = ""
    @State private var password = ""
    @Binding var isUserAuthenticated: Bool
    
    var body: some View {
        
        VStack {
            Spacer()
            Text("Login")
                .font(.largeTitle)
                .padding().foregroundStyle(Color.white)
            
            TextField("Email", text: $email)
                .autocapitalization(.none)
                .padding()
                .background(Color.white)
                .cornerRadius(5)
            
            SecureField("Password", text: $password)
                .padding()
                .background(Color.white)
                .cornerRadius(5)
            
            Button(action: loginUser) {
                Text("Login")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding(.top, 20)
            
            NavigationLink("Don’t have an account? Sign up", destination: SignupScreen(isUserAuthenticated: $isUserAuthenticated))
                .padding(.top, 10)
            
            Spacer()
        }
        .padding().background(Color.black)
    }
    
    // Simulated login function
    func loginUser() {
        // Set isUserAuthenticated to true to simulate successful login
        isUserAuthenticated = true
    }
}


#Preview {
    LoginScreen(isUserAuthenticated: Binding.constant(false))
}

