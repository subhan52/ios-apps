//
//  ContentView.swift
//  Authapp
//
//  Created by Mohd Abdul Subhan on 10/27/24.
//

import SwiftUI

struct ContentView: View {
    @State private var isUserAuthenticated = false
        
        var body: some View {
            NavigationView {
                if isUserAuthenticated {
                    // Show WelcomeScreen if the user is authenticated
                    WelcomeScreen()
                } else {
                    // Show LoginScreen if the user is not authenticated
                    LoginScreen(isUserAuthenticated: $isUserAuthenticated)
                }
            }
        }
}

#Preview {
    ContentView()
}
