//
//  WelcomeScreen.swift
//  Authapp
//
//  Created by Mohd Abdul Subhan on 10/27/24.
//

import SwiftUI

struct WelcomeScreen: View {
    var body: some View {
        VStack {
            Spacer()
            Text("Welcome!")
                .font(.system(size: 80))
                .padding()
            
            Text("You are now logged in.")
                .font(.title)
                .padding()
            
            Spacer()
        }.foregroundColor(Color.white)
        .padding().background(Image("bgimg"))
    }
}

#Preview {
    WelcomeScreen()
}
