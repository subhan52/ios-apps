//
//  App_DuckApp.swift
//  App_Duck
//
//  Created by Bibhu Basnet on 11/26/24.
//

import SwiftUI
import Firebase
import FirebaseAuth

@main
struct App_DuckApp: App {
    @State var isLoggedIn: Bool = true
    
    init() {
        FirebaseApp.configure() // Initialize Firebase
    }

    var body: some Scene {
        WindowGroup {
            // Pass the isLoggedIn state to the SplashScreen and wrap it in a Binding
            SplashScreen(isLoggedIn: $isLoggedIn)
                .environmentObject(FirebaseService()).onAppear(perform: checkLoginStatus) // Inject FirebaseService
        }
    }
    // Function to check Firebase authentication status
        private func checkLoginStatus() {
            if Auth.auth().currentUser != nil {
                isLoggedIn = true
            } else {
                isLoggedIn = false
            }
        }
}
