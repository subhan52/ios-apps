//
//  ExamAppFinalTests.swift
//  ExamAppFinalTests
//
//  Created by Mohd Abdul Subhan on 11/12/24.
//

import Testing
@testable import ExamAppFinal

struct ExamAppFinalTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
