//
//  BarChartView.swift
//  ExamAppFinal
//
//  Created by Mohd Abdul Subhan on 11/12/24.
//

import SwiftUI
import Charts

struct BarChartView: View {
    let percentages: [ContentView.GradeGroup]
    
    var body: some View {
        VStack {
            Text("Grade Distribution")
                .font(.headline)
                .padding()
            
            Chart {
                ForEach(percentages, id: \.grade) { group in
                    BarMark(
                        x: .value("Grade", group.grade),
                        y: .value("Percentage", group.percentage)
                    )
                    .foregroundStyle(.green)
                    .cornerRadius(5)
                }
            }
            .frame(height: 300)
            .padding()
            
                VStack(alignment: .leading) {
                ForEach(percentages, id: \.grade) { group in
                    Text("\(group.grade): \(String(format: "%.2f", group.percentage))%")
                        .padding(.bottom, 2)
                }
            }
            .padding()
        }
        .navigationTitle("Bar Chart View")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct BarChartView_Previews: PreviewProvider {
    static var previews: some View {
        BarChartView(percentages: [
            ContentView.GradeGroup(grade: "A", percentage: 40)
        ])
    }
}
