//
//  ExamAppFinalApp.swift
//  ExamAppFinal
//
//  Created by Mohd Abdul Subhan on 11/12/24.
//

import SwiftUI

@main
struct ExamAppFinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
