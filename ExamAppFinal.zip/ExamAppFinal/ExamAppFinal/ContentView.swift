//
//  ContentView.swift
//  ExamAppFinal
//
//  Created by Mohd Abdul Subhan on 11/12/24.
//
import SwiftUI
import Charts

struct ContentView: View {
    @State private var totalStudents: String = ""
    @State private var groupA: String = ""
    @State private var groupB: String = ""
    @State private var groupC: String = ""
    @State private var groupD: String = ""
    @State private var groupF: String = ""
    
    @State private var percentages: [GradeGroup] = []
    @State private var showResult = false
    
    struct GradeGroup {
        let grade: String
        let percentage: Double
    }
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("Enter Student Data")
                    .font(.headline)
                    .padding()
                
                // Total number of students
                TextField("Total Students", text: $totalStudents)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.roundedBorder)
                    .padding()
                
                // Number of students in each group
                Group {
                    TextField("Group A", text: $groupA)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                        .padding()
                    TextField("Group B", text: $groupB)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                        .padding()
                    TextField("Group C", text: $groupC)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                        .padding()
                    TextField("Group D", text: $groupD)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                        .padding()
                    TextField("Group F", text: $groupF)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                        .padding()
                }
                
                Button(action: {
                    calculatePercentages()
                }) {
                    Text("Show Bar Chart")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(8)
                }
                .padding()
                
                NavigationLink(destination: BarChartView(percentages: percentages), isActive: $showResult) {
                    EmptyView()
                }
            }
        }
    }
    
    private func calculatePercentages() {
        guard let total = Int(totalStudents),
              let a = Int(groupA), let b = Int(groupB),
              let c = Int(groupC), let d = Int(groupD), let f = Int(groupF) else {
            
            // Show an error alert if input is invalid
            return
        }
        
        let totalStudents = Double(total)
        percentages = [
            GradeGroup(grade: "A", percentage: (Double(a) / totalStudents) * 100),
            GradeGroup(grade: "B", percentage: (Double(b) / totalStudents) * 100),
            GradeGroup(grade: "C", percentage: (Double(c) / totalStudents) * 100),
            GradeGroup(grade: "D", percentage: (Double(d) / totalStudents) * 100),
            GradeGroup(grade: "F", percentage: (Double(f) / totalStudents) * 100)
        ]
        
        showResult = true
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

