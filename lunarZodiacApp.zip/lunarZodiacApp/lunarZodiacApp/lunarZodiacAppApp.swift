//
//  lunarZodiacAppApp.swift
//  lunarZodiacApp
//
//  Created by Mohd Abdul Subhan on 10/13/24.
//

import SwiftUI

@main
struct lunarZodiacAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
