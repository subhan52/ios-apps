//
//  ContentView.swift
//  lunarZodiacApp
//
//  Created by Mohd Abdul Subhan on 10/13/24.
//

import SwiftUI

struct ContentView: View {
    let imageNames = ["RABBIT","ROOSTER","DOG","DRAGON","GOAT","HORSE","MONKEY","OX","PIG","RAT","SNAKE","TIGER"]
    
    @State private var year: Int = 2024
    @State private var Imagename: Int = 1
    @State private var imageIndex : Int = 0;
    
    
    
    var body: some View {
        VStack {
            Text(String(year)).font(.largeTitle).bold()
            Spacer()
            
            Image(imageNames[imageIndex]).resizable().scaledToFit()
            Text(imageNames[imageIndex]).font(.largeTitle).bold()
            Spacer()
            HStack{
                Button("<"){
                    year -= 1
                    if((imageIndex - 1) % imageNames.count < 0 ){
                        imageIndex = 0
                    }else {
                        imageIndex = (imageIndex - 1) % imageNames.count
                    }
                }
                Button(">"){
                    year += 1
                    imageIndex = (imageIndex + 1) % imageNames.count
                }
            }.buttonStyle(.borderedProminent)
                .tint(.red).font(.largeTitle).fontWeight(.black)
            Text("SwiftUI is great!")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
