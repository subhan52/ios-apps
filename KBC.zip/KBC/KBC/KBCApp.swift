//
//  KBCApp.swift
//  KBC
//
//  Created by Mohd Abdul Subhan on 12/7/24.
//

import SwiftUI

@main
struct KBCApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreen()
        }
    }
}
