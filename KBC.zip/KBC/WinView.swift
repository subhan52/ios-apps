//
//  WinView.swift
//  KBC
//
//  Created by Mohd Abdul Subhan on 12/7/24.
//

import SwiftUI

struct WinView: View {
    let yourEarnings: Int

    var body: some View {
        VStack {
            Text("You Won!")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()

            Text("Congratulations, your score is \(yourEarnings)")
                .font(.title)
                .padding()

            Button(action: {
                //exit the app();
            }) {
                Text("Done")
                    .font(.title2)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
                    .foregroundColor(.white)
            }
        }
    }
}

#Preview {
    WinView(yourEarnings: 100)
}
